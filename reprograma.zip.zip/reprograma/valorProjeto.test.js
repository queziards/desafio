const {calcularValorotalProjeto} = require('../../dominio/calculadora/Projeto/valorProjeto');
const pacote = require('../../../src/dominio/calculadora/Projeto/pacote');

jest.mock('../../../src/dominio/calculadora/Projeto/pacote');

describe('valor do projeto', () => {
    beforeEach(() => {
        pacote.calcularPacote.mockReturnValue('pacote_basico');
    })
    it('calcular o valor total do projeto para o pacote básico', () => {
        const horasProjeto = 100; 
        const valorEsperado = 2000; 

        const valorCalculado = calcularValorTotalProjeto(horasProjeto);

        expect(valorCalculado).toBe(valorEsperado);
    });

});