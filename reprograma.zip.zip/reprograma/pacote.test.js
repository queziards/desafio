const { calcularPacote } = require("../../dominio/calculadora/Projeto/pacote")



    describe('calcula pacote correto', () => {
        test('retorna pacote basico para total de horas até 50', () => {
            expect(calcularPacote(49)).toEqual('pacote_basico');
            expect(calcularPacote(50)).toEqual('pacote_basico');  
        });
    
        test('retorna pacote diferente para total de horas acima de 50', () => {
            expect(calcularPacote(51)).not.toEqual('pacote_basico');
        });
    });
    